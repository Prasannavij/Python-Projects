from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Eligibility functions (based on your original logic)
def calculate_home_loan_eligibility(details):
    min_age = 21
    max_age = 60
    min_income = 50000  # Minimum income requirement (₹)
    min_credit_score = 650  # Minimum credit score requirement
    min_dti = 20  # Minimum Debt-to-Income ratio (in percentage)
    max_dti = 40  # Maximum Debt-to-Income ratio (in percentage)
    min_down_payment_percentage = 20  # Minimum down payment percentage
    ltv_ratio_threshold = 80  # Loan-to-Value ratio threshold (in percentage)

    # Age check
    if details['age'] < min_age or details['age'] > max_age:
        return False, "Age is not within the eligible range for a Home Loan."

    # Calculate DTI (Debt-to-Income) ratio
    dti_ratio = (details['existing_debts'] / details['income']) * 100

    # Calculate LTV (Loan-to-Value) ratio
    ltv_ratio = (details['loan_amount'] / details['property_value']) * 100
    
    down_payment_percentage = (details['down_payment'] / details['property_value']) * 100

    # Check eligibility conditions
    if details['income'] < min_income:
        return False, "Income is below the minimum required."

    if details['credit_score'] < min_credit_score:
        return False, "Credit score is too low."

    if dti_ratio < min_dti:
        return False, f"Debt-to-Income (DTI) ratio is too low at {dti_ratio:.2f}%. You may not have enough credit history."

    if dti_ratio > max_dti:
        return False, f"Debt-to-Income (DTI) ratio is too high at {dti_ratio:.2f}%."

    if down_payment_percentage < min_down_payment_percentage:
        return False, f"Down payment is less than the minimum required {min_down_payment_percentage}%."

    if ltv_ratio > ltv_ratio_threshold:
        return False, f"Loan-to-Value (LTV) ratio is too high at {ltv_ratio:.2f}%."
    
    return True, "Eligible for the loan."

def calculate_personal_loan_eligibility(details):
    min_age = 21
    max_age = 60
    min_income = 25000  # Minimum income requirement (₹)
    min_credit_score = 600  # Minimum credit score requirement
    min_dti = 10  # Minimum Debt-to-Income ratio (in percentage)
    max_dti = 50  # Maximum Debt-to-Income ratio (in percentage)

    # Age check
    if details['age'] < min_age or details['age'] > max_age:
        return False, "Age is not within the eligible range for a Personal Loan."

    # Calculate DTI (Debt-to-Income) ratio
    dti_ratio = (details['existing_debts'] / details['income']) * 100

    # Check eligibility conditions
    if details['income'] < min_income:
        return False, "Income is below the minimum required."

    if details['credit_score'] < min_credit_score:
        return False, "Credit score is too low."

    if dti_ratio < min_dti:
        return False, f"Debt-to-Income (DTI) ratio is too low at {dti_ratio:.2f}%. You may not have enough credit history."

    if dti_ratio > max_dti:
        return False, f"Debt-to-Income (DTI) ratio is too high at {dti_ratio:.2f}%."

    return True, "Eligible for the loan."

def calculate_vehicle_loan_eligibility(details):
    min_age = 21
    max_age = 65
    min_income = 30000  # Minimum income requirement (₹)
    min_credit_score = 650  # Minimum credit score requirement
    min_dti = 15  # Minimum Debt-to-Income ratio (in percentage)
    max_dti = 45  # Maximum Debt-to-Income ratio (in percentage)
    min_down_payment_percentage = 15  # Minimum down payment percentage
    ltv_ratio_threshold = 90  # Loan-to-Value ratio threshold (in percentage)

    # Age check
    if details['age'] < min_age or details['age'] > max_age:
        return False, "Age is not within the eligible range for a Vehicle Loan."

    # Calculate DTI (Debt-to-Income) ratio
    dti_ratio = (details['existing_debts'] / details['income']) * 100

    # Calculate LTV (Loan-to-Value) ratio
    ltv_ratio = (details['loan_amount'] / details['vehicle_value']) * 100
    
    down_payment_percentage = (details['down_payment'] / details['vehicle_value']) * 100

    # Check eligibility conditions
    if details['income'] < min_income:
        return False, "Income is below the minimum required."

    if details['credit_score'] < min_credit_score:
        return False, "Credit score is too low."

    if dti_ratio < min_dti:
        return False, f"Debt-to-Income (DTI) ratio is too low at {dti_ratio:.2f}%. You may not have enough credit history."

    if dti_ratio > max_dti:
        return False, f"Debt-to-Income (DTI) ratio is too high at {dti_ratio:.2f}%."

    if down_payment_percentage < min_down_payment_percentage:
        return False, f"Down payment is less than the minimum required {min_down_payment_percentage}%."

    if ltv_ratio > ltv_ratio_threshold:
        return False, f"Loan-to-Value (LTV) ratio is too high at {ltv_ratio:.2f}%."

    return True, "Eligible for the loan."

def calculate_educational_loan_eligibility(details):
    min_academic_performance = 60  # Minimum academic performance required (in percentage)
    min_cosigner_credit_score = 600  # Minimum credit score for co-signer

    # Convert academic performance to float for comparison
    try:
        academic_performance = float(details["academic_performance"])
    except ValueError:
        return False, "Invalid academic performance value."

    # Calculate debt-to-income ratio
    if details["has_parents"]:
        debt_to_income_ratio = details["family_existing_debts"] / details["family_income"]
    else:
        debt_to_income_ratio = details["existing_debts"] / details["loan_amount"]

    if details["has_parents"]:
        # Eligibility conditions for applicants with parents (co-signer)
        try:
            cosigner_credit_score = int(details["cosigner_credit_score"])
        except ValueError:
            return False, "Invalid CIBIL score value."

        if cosigner_credit_score < min_cosigner_credit_score:
            return False, "Co-signer's credit score is too low."

        if academic_performance < min_academic_performance:
            return False, "Academic performance is below the required threshold."

    else:
        # Eligibility conditions for applicants without parents (no co-signer)
        if academic_performance < min_academic_performance:
            return False, "Academic performance is below the required threshold."

        if not details["collateral"]:
            return False, "Collateral is required for applicants without a co-signer."

    return True, "Eligible for the loan."

def calculate_business_loan_eligibility(details):
    min_business_age = 23  # Minimum business age in years
    min_credit_score = 650  # Minimum credit score requirement
    min_dscr = 1.25  # Minimum Debt Service Coverage Ratio (DSCR)
    max_ltv = 80  # Maximum Loan-to-Value ratio in percentage

    # Age check
    if details["business_age"] > min_business_age:
        return False, "Business age is below the minimum required for a Business Loan."

    # Calculate DSCR (Debt Service Coverage Ratio)
    total_debt_service = details["existing_debts"] * 12 + (details["loan_amount"] / details["business_age"])  # Approximation
    dscr = details["business_profit"] / total_debt_service

    # Calculate LTV (Loan-to-Value) ratio
    if details["collateral"] > 0:
        ltv_ratio = (details["loan_amount"] / details["collateral"]) * 100
    else:
        ltv_ratio = float('inf')  # No collateral provided, LTV is irrelevant

    # Check eligibility conditions
    if details["credit_score"] < min_credit_score:
        return False, "Credit score is too low."

    if dscr < min_dscr:
        return False, f"Debt Service Coverage Ratio (DSCR) is too low at {dscr:.2f}. Your business may not generate enough income to cover the loan."

    if ltv_ratio > max_ltv:
        return False, f"Loan-to-Value (LTV) ratio is too high at {ltv_ratio:.2f}%. Your collateral may not be sufficient."

    return True, "Eligible for the loan."


# Route for the main page
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        loan_type = request.form['loan_type']
        if loan_type == 'home':
            return redirect(url_for('home_loan'))
        elif loan_type == 'personal':
            return redirect(url_for('personal_loan'))
        elif loan_type == 'vehicle':
            return redirect(url_for('vehicle_loan'))
        elif loan_type == 'educational':
            return redirect(url_for('educational_loan'))
        elif loan_type == 'business':
            return redirect(url_for('business_loan'))
    return render_template('index.html')

# Route for the home loan page
@app.route('/home-loan', methods=['GET', 'POST'])
def home_loan():
    if request.method == 'POST':
        details = {
            'age': int(request.form['age']),
            'income': float(request.form['gross_income']),
            'credit_score': int(request.form['credit_score']),
            'employment_status': request.form['employment_status'],
            'loan_amount': float(request.form['loan_amount']),
            'down_payment': float(request.form['down_payment']),
            'property_value': float(request.form['property_value']),
            'existing_debts': float(request.form['debt_payments']),
            'loan_tenure': int(request.form['loan_tenure']),
        }
        eligible, message = calculate_home_loan_eligibility(details)
        return render_template('result.html', eligible=eligible, message=message)
    return render_template('home_loan.html')

# Route for the personal loan page
@app.route('/personal-loan', methods=['GET', 'POST'])
def personal_loan():
    if request.method == 'POST':
        details = {
            'age': int(request.form['age']),
            'income': float(request.form['gross_income']),
            'credit_score': int(request.form['credit_score']),
            'employment_status': request.form['employment_status'],
            'loan_amount': float(request.form['loan_amount']),
            'existing_debts': float(request.form['debt_payments']),
            'loan_tenure': int(request.form['loan_tenure']),
        }
        eligible, message = calculate_personal_loan_eligibility(details)
        return render_template('result.html', eligible=eligible, message=message)
    return render_template('personal_loan.html')

# Route for the vehicle loan page
@app.route('/vehicle-loan', methods=['GET', 'POST'])
def vehicle_loan():
    if request.method == 'POST':
        details = {
            'age': int(request.form['age']),
            'income': float(request.form['gross_income']),
            'credit_score': int(request.form['credit_score']),
            'employment_status': request.form['employment_status'],
            'loan_amount': float(request.form['loan_amount']),
            'down_payment': float(request.form['down_payment']),
            'vehicle_value': float(request.form['vehicle_value']),
            'existing_debts': float(request.form['debt_payments']),
            'loan_tenure': int(request.form['loan_tenure']),
            'vehicle_type': request.form['vehicle_type'],
        }
        eligible, message = calculate_vehicle_loan_eligibility(details)
        return render_template('result.html', eligible=eligible, message=message)
    return render_template('vehicle_loan.html')

# Route for the educational loan page
@app.route('/educational-loan', methods=['GET', 'POST'])
def educational_loan():
    if request.method == 'POST':
        loan_type = request.form['loan_type']
        if loan_type == 'with_parent':
            details = {
                'family_income': float(request.form['family_income']),
                'cosigner_credit_score': int(request.form['co_signer_credit_score']),
                'cosigner_employment_status': request.form['co_signer_employment'],
                'loan_amount': float(request.form['loan_amount_with_parent']),
                'course_duration': int(request.form['course_duration_with_parent']),
                'course_type': request.form['course_type_with_parent'],
                'institution_type': request.form['institution_type_with_parent'],
                'family_existing_debts': float(request.form['family_debt']),
                'academic_performance': request.form['academic_performance_with_parent'],
                'collateral': request.form['collateral_with_parent'],
                'has_parents': True
            }
        else:
            details = {
                'loan_amount': float(request.form['loan_amount_without_parent']),
                'course_duration': int(request.form['course_duration_without_parent']),
                'course_type': request.form['course_type_without_parent'],
                'institution_type': request.form['institution_type_without_parent'],
                'existing_debts': float(request.form['debt_payments']),
                'academic_performance': request.form['academic_performance_without_parent'],
                'collateral': request.form['collateral_without_parent'],
                'scholarships': request.form['scholarships'],
                'government_support': request.form['government_support'],
                'has_parents': False
            }
        
        # Handle the loan eligibility logic here
        eligible = calculate_educational_loan_eligibility(details)

        return render_template('result.html', eligibility=eligible)
    return render_template('educational_loan.html')


# Route for the business loan page
@app.route('/business-loan', methods=['GET', 'POST'])
def business_loan():
    if request.method == 'POST':
        details = {
            'business_revenue': float(request.form['business_revenue']),
            'business_profit': float(request.form['business_profit']),
            'credit_score': int(request.form['credit_score']),
            'business_age': int(request.form['years_operational']),
            'loan_amount': float(request.form['loan_amount']),
            'loan_purpose': request.form['loan_purpose'],
            'existing_debts': float(request.form['debt_payments']),
            'collateral': float(request.form['collateral_value']),
            'annual_turnover': float(request.form['annual_turnover']),
            'industry_type': request.form['industry_type'],
            'ownership_structure': request.form['ownership_structure']
        }
        eligible, message = calculate_business_loan_eligibility(details)
        return render_template('result.html', eligible=eligible, message=message)
    return render_template('business_loan.html')

if __name__ == '__main__':
    app.run(debug=True)
